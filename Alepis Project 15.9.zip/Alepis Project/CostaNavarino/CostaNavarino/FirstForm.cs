﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CostaNavarino
{
    public partial class FirstForm : Form1
    {
        String connectionString = "Provider=microsoft.Jet.OLEDB.4.0;Data Source=dbusers.mdb";
        OleDbConnection connection;

        public FirstForm()
        {
            InitializeComponent();

            //elitourgia kata tin enarksi tis forms to panel1 einai krymeno
            panel1.Hide();
            
        }

        private void FirstForm_Load(object sender, EventArgs e)
        {
            connection = new OleDbConnection(connectionString);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            // kata to patima h leitoyrgia show emfanizei to panel1
            panel1.Show();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void loginButtonPanel_Click(object sender, EventArgs e)
        {
            // dhmiourgia antikemenou command to opoio trofodotite me mia entoli sql gia th bash h entoli tha rwtaei ti vasi
            //an yparxoun apothikeymena username kai passwords
            OleDbCommand command = new OleDbCommand();
            int i = 0;
            try
            {
                if ((userNameTextBox.Text == "") || (PasswordTextBox.Text == ""))
                {
                    MessageBox.Show("Please fill username and password");
                }
                //stelnw tin entoli sth basi
                command = new OleDbCommand("select * from users where username ='" + userNameTextBox.Text + "'and password ='" + PasswordTextBox.Text + "'", connection);
                //tsekarei an einai kleisti h syndesi kai an einai thn anoigei
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                    i = (int)command.ExecuteScalar();

                }
                connection.Close();

                if (i > 0)
                {
                    MessageBox.Show("Welcome to Costa Navarino");
                    //sthn synexeia afou pathsei to koympi ws xrhsths  tha dhmiougrhsv mia kainouria forma
                    UserForm userForm = new UserForm();
                    //h deyterh forma emfanizetai,tis exv syndesh mesw tou this.h deyterh forma exei owner thn prwth
                    userForm.Show(this);
                    //twra h prwth form1 kryvetai
                    this.Hide();
                }
            }
            catch(Exception exc)
            {
                MessageBox.Show("Invalid username or password");
            }








           
        }
    }
}
